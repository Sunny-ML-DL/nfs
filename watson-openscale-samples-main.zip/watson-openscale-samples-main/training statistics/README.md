# Generating training data distribution

Follow the instructions given in the Notebook to generate the training data distribution.