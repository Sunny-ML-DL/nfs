import math
import time
import pandas as pd
import numpy as np
from datetime import datetime
from docplex.mp.progress import *
from docplex.mp.model import Model

MIP_GAP = 0.02
EXTRA_PERCENTAGE = 1
TIME_LIMIT = 300


# to run the model
def run_model(df_order, df_freight, df_compat):
    start_time = time.time()
    print("date and time =", datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
    # order information
    orders = df_order['OrderID'].values.tolist()
    shipToRefIds = df_order.ShipToRefId.unique().tolist()
    # catPriorities = df_order.CategoryPriority.unique().tolist()
    catPriorities = [0, 1]
    materialCategories = df_order.MaterialCategory.unique().tolist()
    df_order.set_index('OrderID', inplace=True)

    # freight information
    freights = df_freight['FreightID'].values.tolist()
    df_freight.set_index('FreightID', inplace=True)

    # compatibilty table
    df_compat = df_compat.set_index(['Cat1', 'Cat2'])

    # convenient functions
    def get_order(o):
        return df_order.loc[o]

    def get_freight(f):
        return df_freight.loc[f]

    def compat(c1, c2):
        return df_compat.loc[c1, c2].Compatible

    mdl = Model(name='load_planning')
    mdl.add_progress_listener(TextProgressListener(clock="all"))
    mdl.parameters.mip.tolerances.mipgap = MIP_GAP
    mdl.parameters.timelimit = TIME_LIMIT  # in seconds
    # mdl.parameters.mip.tolerances.integrality = 0.00005

    # ---decision variables (result)---
    Assignment = mdl.binary_var_matrix(orders, freights, name='Assignment')

    # ---objective functions---
    # Obj1: Minimise freight cost
    FreightUsed = mdl.binary_var_dict(freights, name='FreightUsed')
    for f in freights:
        FreightUsed[f] = (
                1 <= mdl.sum(Assignment[o, f] for o in orders))

    FreightCost = mdl.sum(FreightUsed[f] * get_freight(f).FreightCost for f in freights)

    # FreightCost = mdl.sum(Assignment[o, f] * get_freight(f).FreightCost for o in orders for f in freights)

    # Obj2: Maximise co-existence of high priority orders amongst loads
    # CPriorityInFreight = mdl.binary_var_matrix(catPriorities, freights, name='CPriorityInFreight')
    # FreightRank = mdl.integer_var_dict(freights, name='FreightRank')
    # for p in catPriorities:
    #     for f in freights:
    #         # CPriorityInFreight[p, f] = 1 <-> priority p is in freight f
    #         mdl.add_constraint(CPriorityInFreight[p, f] == (
    #                 1 <= mdl.sum(Assignment[o, f] for o in orders if get_order(o).CategoryPriority == p)))

    # for f in freights:
    #     # sums == 2 <-> we have both cat 0 and cat 1

    #     mdl.add_constraint(
    #         mdl.if_then((CPriorityInFreight[0, f] == 0) + (CPriorityInFreight[1, f] == 1) == 2, FreightRank[f] == 0))
    #     mdl.add_constraint(
    #         mdl.if_then((CPriorityInFreight[0, f] == 1) + (CPriorityInFreight[1, f] == 0) == 2, FreightRank[f] == 0))
    #     mdl.add_constraint(
    #         mdl.if_then((CPriorityInFreight[0, f] == 0) + (CPriorityInFreight[1, f] == 0) == 2, FreightRank[f] == 0))
    #     mdl.add_constraint(
    #         mdl.if_then((CPriorityInFreight[0, f] == 1) + (CPriorityInFreight[1, f] == 1) == 2, FreightRank[f] == 1))

    # FreightRankSum = mdl.sum(FreightRank[f] for f in freights)



    # max_o1 = df_freight.FreightCost.sum()
    # max_o2 = 2 * df_freight.shape[0]
    # mdl.minimize((FreightCost / max_o1) * 0.4 + (FreightRankSum / max_o2) * 0.6)
    mdl.minimize(FreightCost)
    

    
    # ---constraints---
    # C1: All orders must be fulfilled
    for o in orders:
        mdl.add_constraint(mdl.sum(Assignment[o, f] for f in freights) == 1, "C1")

    # C2: Material category of orders in each load must be compatible
    MCategoryInFreight = mdl.binary_var_matrix(materialCategories, freights, name='MCategoryInFreight')
    for c in materialCategories:
        for f in freights:
            MCategoryInFreight[c, f] = (
                    1 <= mdl.sum(Assignment[o, f] for o in orders if get_order(o).MaterialCategory == c))

    for c1 in materialCategories:
        for c2 in materialCategories:
            if not compat(c1, c2):
                for f in freights:
                    mdl.add_constraint(MCategoryInFreight[c1, f] + MCategoryInFreight[c2, f] <= 1, "C2")

    # C3: The weight of load cannot exceed the carrying capacity of the assigned truck
    for f in freights:
        mdl.add_constraint(mdl.sum(Assignment[o, f] * get_order(o).Weight for o in orders) <= get_freight(f).Capacity,
                           "C3")



    # C5: Orders in a load can originate from at most 2 customers
    ClientInFreight = mdl.binary_var_matrix(shipToRefIds, freights, name='ClientInFreight')

    for s in shipToRefIds:
        for f in freights:
            ClientInFreight[f, s] = (1 <= mdl.sum(Assignment[o, f] for o in orders if get_order(o).ShipToRefId == s))

    for f in freights:
        mdl.add_constraint(mdl.sum(ClientInFreight[f, s] for s in shipToRefIds) <= 2, "C5")

    # ==print model==
    # print(mdl.export_as_lp_string())
    # print(mdl.export_as_lp())

    # ==solve model==
    ok = mdl.solve()
    print("Solving time=", time.time() - start_time, "seconds")

    if ok:
        mdl.print_solution()
        for index, dvar in enumerate(mdl.solution.iter_variables()):
            svar = dvar.to_string()  # Assignment_<orderid>_<freightid>
            if svar.startswith("Assignment_"):
                if dvar.solution_value > 0.99:
                    var = svar.split("_")
                    order_id, freight_id = var[1], var[2]

                    solution_dic['OrderID'].append(order_id)
                    solution_dic['FreightID'].append(freight_id)


# ===data input/output==
outputs = {}
solution_dic = {"OrderID": [], "FreightID": []}
df_freight = None



# utility function for io
def get_input(colName):
    return inputs[colName] #--uncomment
 


def write_output(colName, df):
    outputs[colName]=df #--uncomment
    


df_freight_types = get_input('FreightTypes')
df_order = get_input('Orders')
df_compat = get_input('CompatibilityTable')

# df_order['Destination'] = df_order.Destination.str.upper()

for dest in df_order['Destination'].unique():
    if dest == 'San Antonio':

        df_order_dest = df_order[df_order['Destination'] == dest]
        df_freight_types_dest = df_freight_types[df_freight_types['Destination'] == dest]

        # remove impossible freight type - Selecting the freight type with the minimum cost for the same capacity
        df_freight_types_dest = df_freight_types_dest.loc[
            df_freight_types_dest.groupby('Capacity')['FreightCost'].idxmin()]


        # calculate freight for each freight type, *1.5 to make sure the constraint --todo: to keep/remove 1.5
        # Since say left with 18kg for a freight, a good of 20 kg needs to find another new freight

        total_weight = math.ceil(df_order_dest.Weight.sum())
        df_freight_types_dest['FreightNum'] = (total_weight * 1.5 / df_freight_types_dest['Capacity']).apply(
            np.ceil) * EXTRA_PERCENTAGE
        # output current variable and potential decision variable size, and df_order_dest.shape[0] is number of orders
        # destined for 'San Antonio'.
        decision_variable_size = df_freight_types_dest.FreightNum.sum() * df_order_dest.shape[0]
        print(dest, decision_variable_size)

        # calculate the freight table for dest
        df_freight_dest = df_freight_types_dest.reindex(
            df_freight_types_dest.index.repeat(df_freight_types_dest.FreightNum)).reset_index()

        # calculate the freight id for freight table
        df_freight_dest['FreightID'] = df_freight_dest.index
        if not df_freight is None:
            df_freight_dest['FreightID'] += df_freight.shape[0]

        df_freight_dest = df_freight_dest[
            ['FreightID', 'FreightTypeID', 'FreightCost', 'Destination', 'Capacity', 'Transporter', 'VehicleType']]

        # append for freight table for dest to ultimate freight table
        if df_freight is None:
            df_freight = df_freight_dest.copy()
        else:
            df_freight = df_freight.append(df_freight_dest.copy(), ignore_index=True)

        # run model
        run_model(df_order_dest, df_freight_dest, df_compat)

df_solution = pd.DataFrame(solution_dic)


df_solution['OrderID'] = df_solution['OrderID'].astype(int)
df_solution['FreightID'] = df_solution['FreightID'].astype(int)

df_result = pd.merge(df_solution, df_freight, on=['FreightID'], how='inner')
df_result = pd.merge(df_result, df_order, on=['OrderID'], how='inner')

df_used_freightType = pd.merge(df_freight, df_solution, on=['FreightID'], how='left')
df_used_freightType = df_used_freightType.groupby('FreightTypeID')['OrderID'].apply(
    lambda x: x.notna().all().astype(int)).reset_index(name='UseAll')
df_used_freightType = pd.merge(df_used_freightType, df_freight_types[['FreightTypeID', 'Destination']],
                               on=['FreightTypeID'])

write_output("LoadPlanningResult", df_result)
write_output("Freight", df_freight)
write_output("UseFreightType", df_used_freightType.sort_values(['FreightTypeID']))
